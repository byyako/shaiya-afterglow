Patch kit for the Shaiya EP4.5 client (game.exe)
================================================

A checked, reversible byte patcher for the US Shaiya EP4.5 client. It lets the
game start without the updater, run more than once, show a message the original
code could not, and (only when you ask) a few more changes. It writes a patched
COPY of game.exe, never touches the file you give it, and never runs it. The
game file itself is not included: you patch your own copy.

What each patch does, with its original and patched bytes, is written up at
https://tylerd.me/shaiya/client/client-patch-kit/

Which file
----------
Exactly one build of game.exe:

  SHA-256  5f045bcb4a2e29562ac79effc4108fbaa6404ab29258df02c4dfc6ed7e3401a6
  size     3,203,072 bytes
  built    2010-04-26 (PE timestamp 0x4bd5001e), patch 108, US version

The patcher refuses any other file. The addresses are specific to this build.

Using it (Python 3.8 or newer, no other packages)
-------------------------------------------------
  python3 patch_game_exe.py list   [game.exe]                       every patch and its state
  python3 patch_game_exe.py status game.exe                          which patches are applied, the login address
  python3 patch_game_exe.py apply  game.exe out.exe                  the default set
  python3 patch_game_exe.py apply  game.exe out.exe <id> ...         the default set plus the named patches
  python3 patch_game_exe.py apply  game.exe out.exe --login A.B.C.D  also write a login server address (IPv4)
  python3 patch_game_exe.py revert game.exe out.exe <id> ...         undo the named patches
  python3 patch_game_exe.py revert game.exe out.exe all              undo everything, login address too

The default set is no-updater, skip-updater-wait, multi-client and road-messages.
The others (anti-freeze, no-version, market-anywhere, wall-climb) are applied only
when named. market-anywhere and wall-climb change how the game plays; the server
you connect to should be ready for that.

The output file is a new file. The tool will not write over the input, and will
not replace an existing file unless you add --force. Every change is printed as
before and after bytes, followed by the SHA-256 of the copy.

Safety
------
Before it builds anything the tool undoes, in memory, every patch it recognises
in your file, and the result must have the size and SHA-256 above. So it only
works on this exact build, whether your file is untouched or already carries some
of these patches, and it refuses a file with edits it does not know (including a
game.exe that has been given an extra import for another DLL). Each byte is
checked against its original value just before it is written. After writing, the
copy is read back, classified again, and its original image checked again. If any
step fails, nothing is left behind. A full revert returns the original file byte
for byte.

What was checked
----------------
Each patch was read in the disassembly of this build (see the page above for the
function and address of each). The kit was tested against an independent patcher
that applies the same patches: every patch alone, the default set and all of them
together, with and without a login address, gave byte-identical files; reverting
gave the original hash; repeated apply, wrong files and bad arguments were
refused. Only some of the patches were used in play (the page says which). Keep
your original game.exe and try a copy first.

Files
-----
  patch_game_exe.py   the patcher
  patches.json        the byte lists: for each patch every changed range with its
                      address, file offset, original bytes and patched bytes
  README.txt          this file

No warranty. Shaiya and its trademarks belong to their owners.
