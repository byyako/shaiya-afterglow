#!/usr/bin/env python3
"""Checked, reversible byte patcher for the US Shaiya EP4.5 client (game.exe, patch 108).

It writes a patched COPY of your game.exe and never changes the input. It accepts exactly one build of
game.exe (the SHA-256 and size are in patches.json). Before it writes anything it undoes every patch it
recognises in memory and checks that the result hashes to that build; after writing it reads the copy back
and checks the same again.

  python3 patch_game_exe.py list   [game.exe]                        every patch and, with a file, its state
  python3 patch_game_exe.py status game.exe                           which patches are applied, the login address
  python3 patch_game_exe.py apply  game.exe out.exe [id ...] [--login A.B.C.D] [--force]
  python3 patch_game_exe.py revert game.exe out.exe <id ... | all> [--login-original] [--force]

"apply" with no ids applies the default set. Patches already in the input stay. "revert ... all" also restores
the original login address. Exit codes: 0 done, 1 refused (the reason is printed), 2 usage.
Python 3.8 or newer, no other packages.
"""

import hashlib
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
IPV4 = re.compile(r"^(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$")
ORIGINAL, PATCHED, OTHER = "original", "patched", "other"


class Refused(Exception):
    pass


def load_manifest():
    with open(os.path.join(HERE, "patches.json"), encoding="utf-8") as f:
        doc = json.load(f)
    for p in doc["patches"]:
        for r in p["ranges"]:
            r["off_i"] = int(r["off"], 16)
            r["orig_b"] = bytes.fromhex(r["original"])
            r["new_b"] = bytes.fromhex(r["patched"])
            if len(r["orig_b"]) != len(r["new_b"]):
                raise SystemExit("patches.json: %s has a range whose two byte lists differ in length" % p["id"])
    par = doc["parameters"][0]
    par["off_i"] = int(par["off"], 16)
    par["orig_b"] = bytes.fromhex(par["original"])
    spans = sorted((r["off_i"], r["off_i"] + len(r["orig_b"]), p["id"]) for p in doc["patches"] for r in p["ranges"])
    spans.append((par["off_i"], par["off_i"] + par["length"], par["id"]))
    spans.sort()
    for a, b in zip(spans, spans[1:]):
        if a[1] > b[0]:
            raise SystemExit("patches.json: %s and %s overlap" % (a[2], b[2]))
    return doc


def sha(data):
    return hashlib.sha256(data).hexdigest()


def classify_ip(slot, par):
    """('original', None) / ('ip', 'A.B.C.D') / ('other', None) for the 16-byte login address slot."""
    if slot == par["orig_b"]:
        return ORIGINAL, None
    text, nul, rest = bytes(slot).partition(b"\0")
    if nul and not any(rest):
        try:
            s = text.decode("ascii")
        except UnicodeDecodeError:
            return OTHER, None
        if IPV4.match(s):
            return "ip", s
    return OTHER, None


def classify(data, doc):
    """Per range: original / patched / other. Also the login slot."""
    states = {}
    for p in doc["patches"]:
        for i, r in enumerate(p["ranges"]):
            here = bytes(data[r["off_i"]:r["off_i"] + len(r["orig_b"])])
            states[(p["id"], i)] = ORIGINAL if here == r["orig_b"] else PATCHED if here == r["new_b"] else OTHER
    par = doc["parameters"][0]
    login = classify_ip(bytes(data[par["off_i"]:par["off_i"] + par["length"]]), par)
    return states, login


def patch_state(p, states):
    s = {states[(p["id"], i)] for i in range(len(p["ranges"]))}
    if s == {ORIGINAL}:
        return "off"
    if s == {PATCHED}:
        return "on"
    return "partial" if s <= {ORIGINAL, PATCHED} else "unknown bytes"


def check_input(data, doc):
    """Steps 1 and 2: refuse unknown bytes; rebuild the original image and check its size and hash."""
    t = doc["target"]
    if len(data) != t["size"]:
        raise Refused("the file is %d bytes; the %s this kit knows is %d bytes (a file carrying the .fixes section of "
                      "fixes.dll is longer: use the original)" % (len(data), t["name"], t["size"]))
    states, login = classify(data, doc)
    for p in doc["patches"]:
        for i, r in enumerate(p["ranges"]):
            if states[(p["id"], i)] == OTHER:
                n = len(r["orig_b"])
                raise Refused("%s: unknown bytes at file offset %s: found %s, expected %s (original) or %s (patched)"
                              % (p["id"], r["off"], bytes(data[r["off_i"]:r["off_i"] + n]).hex(), r["original"], r["patched"]))
    for p in doc["patches"]:
        if patch_state(p, states) == "partial":
            raise Refused("%s is only partly applied (some of its ranges are original, some patched); this kit does not "
                          "know that state. Start from the original game.exe" % p["id"])
    par = doc["parameters"][0]
    if login[0] == OTHER:
        raise Refused("login address: unknown bytes at file offset %s: found %s, expected the original address or a "
                      "NUL-padded IPv4 address" % (par["off"], bytes(data[par["off_i"]:par["off_i"] + par["length"]]).hex()))
    image = rebuild_original(data, doc, states)
    if sha(image) != t["sha256"]:
        raise Refused("with every known patch undone this is not the US 2010-04-26 game.exe, patch 108 (SHA-256 %s, "
                      "expected %s), or it has edits this kit does not know" % (sha(image), t["sha256"]))
    return states, login, image


def rebuild_original(data, doc, states):
    image = bytearray(data)
    for p in doc["patches"]:
        for i, r in enumerate(p["ranges"]):
            if states[(p["id"], i)] == PATCHED:
                image[r["off_i"]:r["off_i"] + len(r["orig_b"])] = r["orig_b"]
    par = doc["parameters"][0]
    image[par["off_i"]:par["off_i"] + par["length"]] = par["orig_b"]
    return image


def write_checked(image, r):
    """Write one range into the original image after checking the original bytes are there."""
    n = len(r["orig_b"])
    here = bytes(image[r["off_i"]:r["off_i"] + n])
    if here != r["orig_b"]:
        raise Refused("internal check: expected %s at %s, found %s" % (r["original"], r["off"], here.hex()))
    image[r["off_i"]:r["off_i"] + n] = r["new_b"]


def by_id(doc, ids):
    known = {p["id"]: p for p in doc["patches"]}
    out = []
    for i in ids:
        if i not in known:
            raise Refused("unknown patch %r; run 'list' for the ids" % i)
        if i not in out:
            out.append(i)
    return out


def hexs(b):
    return " ".join("%02X" % x for x in b)


def cmd_list(doc, path):
    states = None
    if path:
        try:
            states, _, _ = check_input(open(path, "rb").read(), doc)
        except Refused as e:
            print("note: %s\n" % e)
    print("%-18s %-12s %-8s %s" % ("id", "category", "default", "state" if states else ""))
    for p in doc["patches"]:
        st = patch_state(p, states) if states else ""
        print("%-18s %-12s %-8s %s" % (p["id"], p["category"], "yes" if p["default"] else "no", st))
        print("    " + p["title"])
    print("\nparameter: --login A.B.C.D  (login server address, IPv4 only)")


def cmd_status(doc, path):
    data = open(path, "rb").read()
    states, login, _ = check_input(data, doc)
    print("%s is the US 2010-04-26 game.exe, patch 108, with:" % path)
    for p in doc["patches"]:
        print("  %-18s %s" % (p["id"], patch_state(p, states)))
    print("  %-18s %s" % ("login address", "original (%s)" % "174.142.118.105" if login[0] == ORIGINAL else login[1]))


def final_report(label, before, after, doc, wanted_ids, expect_login):
    t = doc["target"]
    par = doc["parameters"][0]
    states, login = classify(after, doc)
    for p in doc["patches"]:
        want = PATCHED if p["id"] in wanted_ids else ORIGINAL
        for i, r in enumerate(p["ranges"]):
            if states[(p["id"], i)] != want:
                raise Refused("re-read of the output failed at %s range %d: found %s, intended %s"
                              % (p["id"], i, states[(p["id"], i)], want))
    if login != expect_login:
        raise Refused("re-read of the output failed: login address is %s, intended %s" % (login, expect_login))
    if sha(rebuild_original(after, doc, states)) != t["sha256"]:
        raise Refused("re-read of the output failed: undoing the patches does not give the original")
    print("%s changed ranges (file offset, VA, before -> after):" % label)
    nchanged = 0
    for p in doc["patches"]:
        for r in p["ranges"]:
            a = bytes(before[r["off_i"]:r["off_i"] + len(r["orig_b"])])
            b = bytes(after[r["off_i"]:r["off_i"] + len(r["orig_b"])])
            if a != b:
                nchanged += 1
                print("  %-18s %s (VA %s): %s -> %s" % (p["id"], r["off"], r["va"], hexs(a), hexs(b)))
    a = bytes(before[par["off_i"]:par["off_i"] + par["length"]])
    b = bytes(after[par["off_i"]:par["off_i"] + par["length"]])
    if a != b:
        nchanged += 1
        print("  %-18s %s (VA %s): %s -> %s" % ("login address", par["off"], par["va"], hexs(a), hexs(b)))
    if not nchanged:
        print("  (none: the file already was in this state)")
    return login


def write_output(args_force, src, dst, image, doc, wanted_ids, label):
    if os.path.exists(dst) and os.path.samefile(src, dst):
        raise Refused("the output path is the input file; this tool never edits the input")
    if os.path.exists(dst) and not args_force:
        raise Refused("%s already exists; give another name or use --force" % dst)
    with open(dst, "wb") as f:
        f.write(image)
    after = open(dst, "rb").read()
    if after != bytes(image):
        raise Refused("the written file differs from what was built")
    return after


def cmd_apply(doc, src, dst, ids, login, force):
    data = open(src, "rb").read()
    states, cur_login, image = check_input(data, doc)
    already = [p["id"] for p in doc["patches"] if patch_state(p, states) in ("on", "partial")]
    named = by_id(doc, ids) if ids else [p["id"] for p in doc["patches"] if p["default"]]
    wanted = already + [i for i in named if i not in already]
    par = doc["parameters"][0]
    if login is not None and not IPV4.match(login):
        raise Refused("--login needs an IPv4 address such as 203.0.113.5, got %r" % login)
    out = bytearray(image)
    for p in doc["patches"]:
        if p["id"] in wanted:
            for r in p["ranges"]:
                write_checked(out, r)
    if login is not None:
        out[par["off_i"]:par["off_i"] + par["length"]] = login.encode("ascii").ljust(par["length"], b"\0")
    elif cur_login[0] == "ip":
        out[par["off_i"]:par["off_i"] + par["length"]] = cur_login[1].encode("ascii").ljust(par["length"], b"\0")
    expect = (ORIGINAL, None) if cur_login[0] == ORIGINAL and login is None else         ("ip", login if login is not None else cur_login[1])
    after = write_output(force, src, dst, bytes(out), doc, wanted, "apply")
    verify_and_finish(dst, data, after, doc, wanted, expect, "applied.")


def cmd_revert(doc, src, dst, ids, login_original, force):
    data = open(src, "rb").read()
    states, cur_login, image = check_input(data, doc)
    every = [p["id"] for p in doc["patches"]]
    if ids == ["all"]:
        drop, login_original = every, True
    else:
        drop = by_id(doc, ids)
    keep = [p["id"] for p in doc["patches"] if patch_state(p, states) in ("on", "partial") and p["id"] not in drop]
    par = doc["parameters"][0]
    out = bytearray(image)
    for p in doc["patches"]:
        if p["id"] in keep:
            for r in p["ranges"]:
                write_checked(out, r)
    if not login_original and cur_login[0] == "ip":
        out[par["off_i"]:par["off_i"] + par["length"]] = cur_login[1].encode("ascii").ljust(par["length"], b"\0")
    expect = (ORIGINAL, None) if (login_original or cur_login[0] == ORIGINAL) else ("ip", cur_login[1])
    after = write_output(force, src, dst, bytes(out), doc, keep, "revert")
    verify_and_finish(dst, data, after, doc, keep, expect, "reverted.")


def verify_and_finish(dst, before, after, doc, wanted, expect, label):
    try:
        final_report(label, before, after, doc, wanted, expect)
        finish(dst, after, doc, wanted, expect)
    except Refused:
        os.remove(dst)
        raise


def finish(dst, after, doc, wanted, login_after):
    digest = sha(after)
    print("wrote %s" % dst)
    print("SHA-256 %s" % digest)
    default = [p["id"] for p in doc["patches"] if p["default"]]
    exp = doc.get("expected_sha256_default")
    if exp and sorted(wanted) == sorted(default) and login_after[0] == ORIGINAL:
        if digest != exp:
            raise Refused("default set with the original login address should hash to %s" % exp)
        print("matches the published hash of the default set")
    if wanted == [] and login_after[0] == ORIGINAL:
        print("this is the original game.exe, byte for byte")


def main(argv):
    if len(argv) < 2 or argv[1] in ("-h", "--help", "help"):
        print(__doc__)
        return 2 if len(argv) < 2 else 0
    cmd, rest = argv[1], argv[2:]
    force = "--force" in rest
    rest = [a for a in rest if a != "--force"]
    login = None
    login_original = False
    if "--login" in rest:
        i = rest.index("--login")
        if i + 1 >= len(rest):
            print("--login needs an address", file=sys.stderr)
            return 2
        login = rest[i + 1]
        del rest[i:i + 2]
    if "--login-original" in rest:
        login_original = True
        rest.remove("--login-original")
    if any(a.startswith("--") for a in rest):
        print("unknown option %s" % [a for a in rest if a.startswith("--")][0], file=sys.stderr)
        return 2
    if login is not None and cmd != "apply":
        print("--login belongs to 'apply'", file=sys.stderr)
        return 2
    if login_original and cmd != "revert":
        print("--login-original belongs to 'revert'", file=sys.stderr)
        return 2
    doc = load_manifest()
    try:
        if cmd == "list" and len(rest) <= 1:
            cmd_list(doc, rest[0] if rest else None)
        elif cmd == "status" and len(rest) == 1:
            cmd_status(doc, rest[0])
        elif cmd == "apply" and len(rest) >= 2:
            cmd_apply(doc, rest[0], rest[1], rest[2:], login, force)
        elif cmd == "revert" and len(rest) >= 3:
            cmd_revert(doc, rest[0], rest[1], rest[2:], login_original, force)
        else:
            print(__doc__, file=sys.stderr)
            return 2
    except Refused as e:
        print("refused: %s" % e, file=sys.stderr)
        return 1
    except OSError as e:
        print("refused: %s" % e, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
